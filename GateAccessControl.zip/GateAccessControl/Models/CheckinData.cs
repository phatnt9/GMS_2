﻿namespace GateAccessControl
{
    public class CheckinData
    {
        public string SERIAL_ID { get; set; }
        public string TIMECHECK { get; set; }
    }
}
